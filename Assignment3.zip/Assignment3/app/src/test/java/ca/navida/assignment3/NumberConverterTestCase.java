package ca.navida.assignment3;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class NumberConverterTestCase {
    @Test
    public void testDecimal(){
        NumberConverter	testNumber	=	new NumberConverter();

        /*TESTING CONVERSION TO DECIMAL*/
        testNumber.setDecimalValue("d", "20");
        assertEquals(testNumber.getDecimalValue(),	20);
        testNumber.setDecimalValue("b", "1010");
        assertEquals(testNumber.getDecimalValue(),	10);
        testNumber.setDecimalValue("h", "F");
        assertEquals(testNumber.getDecimalValue(),	15);

        /*TESTING FALSE INPUT*/
        testNumber.setDecimalValue("d1", "20");
        assertEquals(testNumber.getDecimalValue(),	-3);
        testNumber.setDecimalValue("2b", "1010");
        assertEquals(testNumber.getDecimalValue(),	-3);
        testNumber.setDecimalValue("h:", "F");
        assertEquals(testNumber.getDecimalValue(),	-3);
        testNumber.setDecimalValue("d", "F");
        assertEquals(testNumber.getDecimalValue(),	-2);
        testNumber.setDecimalValue("b", "F");
        assertEquals(testNumber.getDecimalValue(),	-2);
        testNumber.setDecimalValue("h", "GQ");
        assertEquals(testNumber.getDecimalValue(),	-2);

        /*TESTING CONVERSION FOR BINARY*/
        testNumber.setDecimalValue("d", "20");
        testNumber.setAfterConverter("b");
        assertEquals(testNumber.getAfterConverter(), "10100");

        /*TESTING CONVERSION FOR HEXADECIMAL*/
        testNumber.setDecimalValue("d", "26");
        testNumber.setAfterConverter("h");
        assertEquals(testNumber.getAfterConverter(), "1A");

        /*TESTING CONVERSION FOR DECIMAL*/
        testNumber.setDecimalValue("d", "20");
        testNumber.setAfterConverter("d");
        assertEquals(testNumber.getAfterConverter(), "20");
    }
}
