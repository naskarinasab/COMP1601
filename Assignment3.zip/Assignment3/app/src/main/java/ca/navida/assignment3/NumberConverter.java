package ca.navida.assignment3;

public class NumberConverter {
    private int decimalValue;
    private String afterConverter;

    /*Get Methods*/
    public int getDecimalValue() {return decimalValue;}
    public String getAfterConverter() {return afterConverter;}

    /*Constructor*/
    public NumberConverter() {
        decimalValue = 0;
        afterConverter = "";
    }

    public void setDecimalValue(String bType, String convert){
        if(bType.equals("d")){
            try
            {
                decimalValue = Integer.parseInt(convert);//converting from binary to decimal
            }
            catch(NumberFormatException nme)
            {
                decimalValue = -2;
            }
        }
        else if(bType.equals("b")){
            try
            {
                decimalValue = Integer.parseInt(convert, 2);//converting from binary to decimal
            }
            catch(NumberFormatException nme)
            {
                decimalValue = -2;
            }
        }
        else if(bType.equals("h")){
            try
            {
                decimalValue = Integer.parseInt(convert, 16); //converting from hexidecimal to decimal
            }
            catch(NumberFormatException nme)
            {
                decimalValue = -2;
            }
        }
        else{ //incase the user enters something else before the : which would be a wrong input like yh:121
            decimalValue = -3; //using -3 to know if the users input was a wrong input
        }
    }

    public void setAfterConverter(String bClicked){
        if(bClicked.equals("d")){
            afterConverter = Integer.toString(decimalValue);
        }
        else if(bClicked.equals("b")){
            afterConverter = Integer.toString(decimalValue, 2); //converting from decimal to binary
        }
        else if(bClicked.equals("h")){
            afterConverter = Integer.toString(decimalValue, 16).toUpperCase(); //converting from decimal to hexadecimal
        }
    }
}
