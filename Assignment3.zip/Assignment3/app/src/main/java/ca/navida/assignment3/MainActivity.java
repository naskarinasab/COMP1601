package ca.navida.assignment3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    String[] userInput;
    NumberConverter n = new NumberConverter();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /*INITIAL SETUP*/
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button aButton1 = (Button)findViewById(R.id.decimal);
        aButton1.setBackgroundResource(R.color.red);
        aButton1.setTextColor(getResources().getColor(R.color.blue));
        final Button aButton2 = (Button) findViewById(R.id.binary);
        aButton2.setBackgroundResource(R.color.red);
        aButton2.setTextColor(getResources().getColor(R.color.blue));
        final Button aButton3 = (Button) findViewById(R.id.hex);
        aButton3.setBackgroundResource(R.color.red);
        aButton3.setTextColor(getResources().getColor(R.color.blue));


        aButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update("d");
            }
        });
        aButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update("b");
            }
        });
        aButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update("h");
            }
        });
    }


    public void updateColors(String bClicked){
        /*Resetting colors*/
        ((Button)findViewById(R.id.decimal)).setBackgroundResource(R.color.red);
        ((Button)findViewById(R.id.binary)).setBackgroundResource(R.color.red);
        ((Button)findViewById(R.id.hex)).setBackgroundResource(R.color.red);
        /*Finding and coloring the background green*/
        if(bClicked == "d"){
            ((Button)findViewById(R.id.decimal)).setBackgroundResource(R.color.green);
        }
        else if(bClicked == "b"){
            ((Button)findViewById(R.id.binary)).setBackgroundResource(R.color.green);
        }
        else if(bClicked == "h"){
            ((Button)findViewById(R.id.hex)).setBackgroundResource(R.color.green);
        }
    }

    public void update(String buttonClicked){
        EditText text = (EditText)findViewById(R.id.user);
        userInput = text.getText().toString().split(":", 2); //splitting the array into two.
        updateColors(buttonClicked);
        if(userInput.length == 2){ //to avoid situations where no ":" are used
            n.setDecimalValue(userInput[0], userInput[1]);
            if(n.getDecimalValue() >= 0){ //if they entered a correct input, the converted number should be bigger than or equal to 0
                n.setAfterConverter(buttonClicked);
                text.setText(buttonClicked + ":" + n.getAfterConverter(), TextView.BufferType.EDITABLE);
            }
            else{
                error(text);
            }
        }
        else{
            error(text);
        }

    }

    public void error(EditText text){
        text.setText("ERROR!", TextView.BufferType.EDITABLE);
    }
}
